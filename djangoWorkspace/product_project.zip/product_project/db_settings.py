DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.mysql",  # 엔진
        "NAME": "django_db",  # 데이터베이스 이름
        "USER": "root",  # 사용자
        "PASSWORD": "wjd900105!",  # 비밀번호
        "HOST": "localhost",  # 호스트
        "PORT": "3306",  # 포트번호
    }
}


# SECRET_KEY
SECRET_KEY = "django-insecure-x2)5e3qt_ype9gz4i5ubto-=zgg!ygk6*jv!sohx0aye5tx$!r"
