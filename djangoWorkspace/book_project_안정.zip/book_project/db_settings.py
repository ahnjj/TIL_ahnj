DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.mysql",  # 엔진
        "NAME": "book_db",  # 데이터베이스 이름
        "USER": "root",  # 사용자
        "PASSWORD": "wjd900105!",  # 비밀번호
        "HOST": "localhost",  # 호스트
        "PORT": "3306",  # 포트번호
    }
}


SECRET_KEY = '$bxsd4e!arror_v8drydl&s%ic@l5!u6f(qwe7u@#k!#)9oatd'
